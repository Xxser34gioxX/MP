package jeroquest.units;

public class FuriousMummy extends Mummy{
	
	public FuriousMummy(String itsName, int itsMovement, int itsAttack, int itsDefence, int itsBody) {
		super(itsName);
		// TODO Auto-generated constructor stub
		
	}
	@Override
	public int defend(int impacts) {
		
		// if there are not blocked impacts reduce body points
		if (impacts > 0) {
			// a character life cannot be lower than zero
			setBody(Math.max(0, getBody() - impacts));
			System.out.printf("The mummy " + this.getName() + " cannot block %d impacts%s", impacts,
					(isAlive() ? "\n" : " and dies\n"));
		} else {
			System.out.printf("The mummy " + this.getName() + " blocks completely the attack\n");
		}

		return impacts;
	}
	
	public int attack() {
		return 2*super.attack();
		}

	/**
	 * Generate a printable String version of the object (overriden method)
	 * 
	 * @return the barbarian's printable info as a String
	 */
	@Override
	 public String toString() {
        return String.format("The furious mummy: %s", super.toString());
    }
}
