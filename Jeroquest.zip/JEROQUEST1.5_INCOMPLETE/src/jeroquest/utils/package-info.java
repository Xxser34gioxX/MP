/**
 * Provides the classes necessary to represent different auxiliary classes.
 * 
 * @author Programming Methodology Professors
 */
package jeroquest.utils;