
public class CommissionAndBasePlusEmployeesMain {

	public static void main(String[] args) {
		// TODO 

	}
}
