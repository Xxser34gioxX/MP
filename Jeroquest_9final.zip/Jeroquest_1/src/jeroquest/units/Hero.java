package jeroquest.units;

import jeroquest.utils.Dice;

public abstract class Hero extends Character{
	protected String namePlayer;
	private Weapon weapon;
	public Hero(String itsName, int itsMovement, int itsAttack, int itsDefence, int itsBody, String namePlayer, Weapon weapon) {
		super(itsName, itsMovement, itsAttack, itsDefence, itsBody);
		setnamePlayer(namePlayer);
		setWeapon(weapon);
	}
	
	public String getnamePlayer() {
		return namePlayer;
	}
	
	public void setnamePlayer(String namePlayer) {
		this.namePlayer = "no name";
	}
	//Reeescribir el metodo de ataque con arma que tienen en comun 
	@Override
	public int getAttack() {
		return weapon != null ? weapon.getAttack() : super.getAttack();
	}
	
	//Getters y setters de weapon
	public Weapon getWeapon() {
		// TODO Auto-generated method stub
		return weapon;
	}
	public void setWeapon(Weapon object) {
		this.weapon=object;
	}
	
	/**
	 * The barbarian defends itself from an attack (Implementing an inherited
	 * abstract method)
	 * 
	 * @param impacts the total number of impacts to try to block or receive
	 * @return the number of wounds suffered
	 */
	@Override
	public int defend(int impacts) {
		// trying to block the impacts with its defence
		for (int totalDefenceDices = getDefence(); (impacts > 0) && (totalDefenceDices > 0); totalDefenceDices--)
			if (Dice.roll() > 4) // a 5 or 6 is necessary to block an impact
				impacts--;

		// if there are unblocked impacts reduce body points
		if (impacts > 0) {
			// a character life cannot be lower than zero
			setBody(Math.max(0, getBody() - impacts));
			System.out.printf("The barbarian " + this.getName() + " cannot block %d impacts%s", impacts,
					(isAlive() ? "\n" : " and dies\n"));
		} else {
			System.out.printf("The barbarian " + this.getName() + " blocks completely the attack\n");
		}

		return impacts;
	}

	@Override
	public String toString() {
		return "Hero [namePlayer=" + namePlayer + ", weapon=" + weapon + "]";
	}
	
}
