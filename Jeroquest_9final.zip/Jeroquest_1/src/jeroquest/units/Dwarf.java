package jeroquest.units;
import jeroquest.utils.Dice;

public class Dwarf extends Hero{
	
	protected static final int MOVEMENT = 6;
	protected static final int ATTACK = 1;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 8;
	
	public Dwarf(String itsName) {
		this(itsName,"no name",new Weapon("Hand axe", 2));
		// TODO Auto-generated constructor stub
	}
	
	public Dwarf(String itsName, String playerName, Weapon weapon) {
		super(itsName, MOVEMENT, ATTACK, DEFENCE, BODY, playerName, new Weapon("Hand axe", 2));
	}

	/**
	 * Generate a printable String version of the object (overriden method)
	 * 
	 * @return the barbarian's printable info as a String
	 */
	@Override
	 public String toString() {
       return String.format("The Drwarf: %s, Weapon: %s", super.toString(),
               (super.getWeapon() != null ? super.toString() : "No weapon"));
    }
	
}
