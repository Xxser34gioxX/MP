package jeroquest.units;
import jeroquest.utils.Dice;

/**
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * Programming. Class Barbarian
 * 
 * @author Jorge Puente Peinador y Ramiro Varela Arias
 * @author Juan Luis Mateo Cerdán
 * @version 1
 * 
 */

public class Barbarian extends Hero {
	// initial value for the attributes
	protected static final int MOVEMENT = 7;
	protected static final int ATTACK = 1;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 8;
	/**
	 * Create a barbarian with its name
	 * 
	 * @param itsName Barbarian's name
	 */

	public Barbarian(String itsName) {
		this(itsName,"no name", new Weapon ("Broadsword", 3));
		// TODO Auto-generated constructor stub
	}
	
	public Barbarian(String itsName, String playerName, Weapon weapon) {
		super(itsName, MOVEMENT, ATTACK, DEFENCE, BODY, playerName, weapon);
	}

	/**
	 * Generate a printable String version of the object (override method)
	 * 
	 * @return the barbarian's printable info as a String
	 */
	@Override
	 public String toString() {
        return String.format("The barbarian: %s, Weapon: %s", super.toString(),
                (super.getWeapon() != null ? super.toString() : "No weapon"));
	}
}
