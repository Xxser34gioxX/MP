package jeroquest;
import jeroquest.units.Barbarian;
import jeroquest.units.Dwarf;
import jeroquest.units.FuriousMummy;
import jeroquest.units.Mummy;
import jeroquest.utils.Dice;

/**
 * Programming Methodology Practice.
 * Jeroquest - An example of Object Oriented Programming.
 * Main program
 * @author Jorge Puente Peinador y Ramiro Varela Arias
 * @author Juan Luis Mateo Cerdán
 * @version 1
 *
 */

public class JeroquestMain {

	public static void main(String[] args) {
		int vectorinstanced = 5;
		Mummy ramses = new Mummy("Ramses");
		Barbarian conan = new Barbarian("Conan");
		
		Mummy[] momia = new Mummy[vectorinstanced];
		Barbarian[] barbaro = new Barbarian[vectorinstanced];
		Dwarf[] enano = new Dwarf[vectorinstanced];
		FuriousMummy[] furiosa = new FuriousMummy[vectorinstanced];
		
		System.out.println(ramses);
		System.out.println(conan);
		
		// Conan attacks Ramses
		int impacts = conan.attack();
		ramses.defend(impacts);
		
		// if Ramses is alive attacks Conan
		if (ramses.isAlive())
			conan.defend(ramses.attack());
			
		System.out.println(ramses);
		System.out.println(conan);
		game(momia, barbaro);
		
		System.out.println("Las momias estan ordenados: " + sortedB(barbaro, vectorinstanced));
		System.out.println("Las momias estan ordenados: " + sortedM(momia, vectorinstanced));
	}
	//Ejercicio c
	
	/*
	public static void game(Mummy[] momia, Barbarian[] barbaro) {
		int turns = 5;
		int impacts = 0;
		
		for(int t = 0; t < turns && comprobarSiEstanVivos(momia, barbaro); t++) {
			for (int i = 0; i < barbaro.length; i++) {
				int r = Dice.roll(barbaro.length) - 1;
				if(barbaro[i].isAlive()) {
					impacts = barbaro[i].attack();
					momia[r].defend(impacts);
				}
				r = Dice.roll(barbaro.length) - 1;
				if(momia[i].isAlive()) {
					impacts = momia[i].attack();
					barbaro[r].defend(impacts);
				}	
			}
		}

	}
	*/
	//Apartado d
	
	public static void game(Mummy[] momia, Barbarian[] barbaro) {
		int turns = 5;
		int impacts = 0;
		
		for(int t = 0; t < turns && comprobarSiBarbaroEstaVivo(barbaro) && comprobarSiMomiaEstaViva(momia); t++) {
			for (int i = 0; i < barbaro.length; i++) {
				if(barbaro[i].isAlive()) {
					impacts = barbaro[i].attack();
					momia[whoHasMoreLife(momia, barbaro)[1]].defend(impacts);
				}
				if(momia[i].isAlive()) {
					impacts = momia[i].attack();
					barbaro[whoHasMoreLife(momia, barbaro)[0]].defend(impacts);
				}	
			}
		}

	}
	
	public static boolean comprobarSiBarbaroEstaVivo(Barbarian[] barbaro) {
		for(int i = 0; i < barbaro.length; i++) {
			if(barbaro[i] != null) {
				if (barbaro[i].isAlive()) return true;
			}
		}
		return false;
	}
	public static boolean comprobarSiMomiaEstaViva(Mummy[] momia) {
		for(int i = 0; i < momia.length; i++) {
			if (momia[i].isAlive()) return true;
		}
		return false;
	}
	
	//ES UN MÉTODO que se utiliza para retornar un vector con el barbaro y con la momia con mayor vida
	public static int[] whoHasMoreLife(Mummy[] momia,Barbarian[] barbaro) {
		int[] vida = new int[2];
		for (int i = 0; i < barbaro.length; i++) {
			//BARBAROS
		
			if (barbaro[i].getBody() < barbaro[i+1].getBody()) {
				vida[0] = barbaro[i+1].getBody();
			}else {
				vida[0] = barbaro[i].getBody();
			}
			//MOMIAS
			
			if (momia[i].getBody() < momia[i+1].getBody()) {
				vida[1] = momia[i+1].getBody();
			}else {
				vida[1] = momia[i].getBody();
			}
		}
		return vida;
	}
	
	//Tuve que crear un nuevo método para ordenarlos de mayor a menor, porque no sabía como reutilizar el otro método
	public static int[] sortedM(Mummy[] momia, int vectorinstanced) {
		Mummy aux;
		int[] sort = new int[vectorinstanced];
		for(int i = 0; i < vectorinstanced; i++) {
			for(int j = 0; j < vectorinstanced; j++) {
				if(momia[j].getBody() < momia[j + 1].getBody()) {
					aux = momia[j];
					momia[j] = momia[j + 1];
					momia[j + 1] = aux;
				}
			}
		}
		return sort;
	}
	
	public static int[] sortedB(Barbarian[] barbaro, int vectorinstanced) {
		Barbarian aux;
		int[] sort = new int[vectorinstanced];
		for(int i = 0; i < vectorinstanced; i++) {
			for(int j = 0; j < vectorinstanced; j++) {
				if(barbaro[j].getBody() < barbaro[j + 1].getBody()) {
					aux = barbaro[j];
					barbaro[j] = barbaro[j + 1];
					barbaro[j + 1] = aux;
				}
			}
		}
		return sort;
	}
}














