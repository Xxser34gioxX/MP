#include <iostream>
#include <cstdlib>  // Para exit()
#include <cstring>  // Para strlen()

using namespace std;

#define ID 308382  // ID de pruebas asignado

void CountVowels() {
    char cadena1[20], cadena2[20];
    int vocales = 0;
    int ID_values[] = { 3, 0, 8, 3, 8, 2 };

    cout << "Ingrese la primera cadena: ";
    cin >> cadena1;

    for (int i = 0; cadena1[i] != '\0'; i++) {
        char c = tolower(cadena1[i]);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            vocales++;
        }
    }

    if (vocales < ID_values[1]) {
        cout << "Intruso detectado" << endl;
        exit(0);
    }

    cout << "Ingrese la segunda cadena: ";
    cin >> cadena2;

    if (strlen(cadena2) < 12 || cadena2[ID_values[3]] != cadena2[ID_values[0]]) {
        cout << "Hubo alg�n fallo" << endl;
        exit(0);
    }
}

void ControlWithBits() {
    unsigned int num1, num2;
    int ID_values[] = { 3, 0, 8, 3, 8, 2 };

    cout << "Ingrese el primer numero: ";
    cin >> num1;
    cout << "Ingrese el segundo numero: ";
    cin >> num2;

    if (((num1 >> ID_values[4]) & 1) != ((num2 >> ID_values[2]) & 1)) {
        cout << "Hubo alg�n fallo" << endl;
        exit(0);
    }

    unsigned int mask = ((1 << (ID_values[3] - ID_values[1] + 1)) - 1) << ID_values[1];
    if ((num2 & mask) != 0) {
        cout << "Entrada incorrecta" << endl;
        exit(0);
    }

    unsigned int newNum = (num1 >> (32 - ID_values[0])) | (num2 & ((1 << (32 - ID_values[0])) - 1));
    if (newNum <= ID_values[1] * 234) {
        cout << "Fallo" << endl;
        exit(0);
    }
}

extern "C" bool IsValidAssembly(int a, int b, int c);

void AsmAccess() {
    int num1, num2, num3;

    cout << "Ingrese tres numeros: ";
    cin >> num1 >> num2 >> num3;

    if (IsValidAssembly(num1, num2, num3) == 0) {
        cout << "Acceso erroneo" << endl;
        exit(0);
    }
}

void CheckVectorValues() {
    unsigned char vec[3];
    int sum = 0;

    cout << "Ingrese tres valores de 8 bits: ";
    for (int i = 0; i < 3; i++) {
        int temp;
        cin >> temp;
        vec[i] = static_cast<unsigned char>(temp);
        sum += vec[i];
    }

    if (sum != 90) {
        cout << "Fallo" << endl;
        exit(0);
    }
}

int main() {
    CountVowels();
    ControlWithBits();
    AsmAccess();
    CheckVectorValues();

    cout << "Acceso permitido" << endl;
    return 0;
}


