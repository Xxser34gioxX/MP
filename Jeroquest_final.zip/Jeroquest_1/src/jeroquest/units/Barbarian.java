package jeroquest.units;
import jeroquest.utils.Dice;

/**
 * Programming Methodology Practice. Jeroquest - An example of Object Oriented
 * Programming. Class Barbarian
 * 
 * @author Jorge Puente Peinador y Ramiro Varela Arias
 * @author Juan Luis Mateo Cerdán
 * @version 1
 * 
 */

public class Barbarian extends Character{
	// initial value for the attributes
	protected static final int MOVEMENT = 7;
	protected static final int ATTACK = 1;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 8;
	private Weapon weapon;
	/**
	 * Create a barbarian with its name
	 * 
	 * @param itsName Barbarian's name
	 */
	public Barbarian(String itsName) {
		// setting the attributes with the initial values
		super(itsName, MOVEMENT, ATTACK, DEFENCE, BODY);
		weapon = new Weapon("Broadsword", 3);
	}
	@Override
	public int getAttack() {
		return weapon != null ? weapon.getAttack() : super.getAttack();
	}
	
	@Override
	public int attack() {
		int impacts = 0;
		for (int x = 0; x < (weapon != null ? weapon.getAttack()-1: super.getAttack()); x++)
			if (Dice.roll() > 3)
				impacts++;
		return impacts;
	}
	/**
	 * The barbarian defends itself from an attack (Implementing an inherited
	 * abstract method)
	 * 
	 * @param impacts the total number of impacts to try to block or receive
	 * @return the number of wounds suffered
	 */
	public int defend(int impacts) {
		// trying to block the impacts with its defence
		for (int totalDefenceDices = getDefence(); (impacts > 0) && (totalDefenceDices > 0); totalDefenceDices--)
			if (Dice.roll() > 4) // a 5 or 6 is necessary to block an impact
				impacts--;

		// if there are unblocked impacts reduce body points
		if (impacts > 0) {
			// a character life cannot be lower than zero
			setBody(Math.max(0, getBody() - impacts));
			System.out.printf("The barbarian " + this.getName() + " cannot block %d impacts%s", impacts,
					(isAlive() ? "\n" : " and dies\n"));
		} else {
			System.out.printf("The barbarian " + this.getName() + " blocks completely the attack\n");
		}

		return impacts;
	}

	/**
	 * Generate a printable String version of the object (overriden method)
	 * 
	 * @return the barbarian's printable info as a String
	 */
	@Override
	 public String toString() {
        return String.format("The barbarian: %s, Weapon: %s", super.toString(),
                (weapon != null ? weapon.toString() : "No weapon"));
    }
	public Weapon getWeapon() {
		// TODO Auto-generated method stub
		return weapon;
	}
	public void setWeapon(Weapon object) {
		this.weapon=object;
		
	}

}
