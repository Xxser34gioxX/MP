/**
 * Provides the {@link JeroquestMain} class with the main() method
 * 
 * @author Programming Methodology Professors
 */
package jeroquest;