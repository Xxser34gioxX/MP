package jeroquest.units;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import jeroquest.units.Barbarian;
import jeroquest.utils.Dice;

public class BarbarianWeaponTest {

	@Test
	void testWeapon() {
		Weapon weapon = new Weapon("Broadsword",3);
		
		assertEquals("Broadsword", weapon.getName());
		assertEquals(3, weapon.getAttack());
		
		// Weapon.setAttack() must update the attack of the weapon
		weapon.setAttack(10);
		assertEquals(10, weapon.getAttack());
		// Weapon.toString() returns the name of the weapon
		assertTrue(weapon.toString().indexOf("Broadsword")>-1);
		// Weapon.toString() returns the attack of the weapon
		assertTrue(weapon.toString().indexOf("10")>-1);
	}

	@Test
	void testWeaponAttribute() {
		Barbarian conan = new Barbarian("Conan");
		
		assertEquals(3, conan.getWeapon().getAttack());
		assertEquals("Broadsword", conan.getWeapon().getName());
		// Barbarian.toString() returns the name of the weapon
		assertTrue(conan.toString().indexOf("Broadsword")>-1);
		// Barbarian.toString() returns the attack of the weapon
		assertTrue(conan.toString().indexOf("3")>-1);
	}
	
	@Test
	void testBarbarianGetAttack() {
		Barbarian conan = new Barbarian("Conan");
		
		assertEquals(3, conan.getAttack());
		conan.setWeapon(null);
		assertEquals(1, conan.getAttack());
	}
	
	@Test
	void testBarbarianAttack() {
		Barbarian conan = new Barbarian("Conan");
		conan.getWeapon().setAttack(10);
		
		Dice.setSeed(0L);
		assertEquals(7,conan.attack()); 
		conan.setWeapon(null);
		assertEquals(1,conan.attack());
	}
	@Test
	void testDwarf() {
		Dwarf dopey = new Dwarf("Dopey");

		assertEquals(2, dopey.getWeapon().getAttack());
		assertEquals("Hand axe", dopey.getWeapon().getName());

		assertEquals(2, dopey.getAttack());
		dopey.getWeapon().setAttack(10);
		assertEquals(10, dopey.getAttack());
		dopey.setWeapon(null);
		assertEquals(1, dopey.getAttack());
		assertEquals(2, dopey.getDefence());
		assertEquals(6, dopey.getMovement());
		assertEquals(7, dopey.getBody());
	}

	@Test
	void testFuriousMummy() {
		FuriousMummy eddie = new FuriousMummy("Eddie");

		assertEquals(3, eddie.getAttack());
		assertEquals(4, eddie.getDefence()); // as a normal mummy
		assertEquals(4, eddie.getMovement());
		assertEquals(2, eddie.getBody());

		Dice.setSeed(1L);
		assertEquals(4, eddie.attack());

		// it does not block any impacts
		eddie.defend(1);
		assertEquals(1, eddie.getBody());
	}
}
